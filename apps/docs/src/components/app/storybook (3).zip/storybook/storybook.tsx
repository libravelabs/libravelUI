import { StoryBookRenderer } from "./renderer";
import { storyRegistry, type StoryName } from "@/components/examples/stories";

type StoryBookProps = {
  story: StoryName;
};

export function StoryBook({ story }: StoryBookProps) {
  const config = storyRegistry[story];

  return <StoryBookRenderer story={config} />;
}
