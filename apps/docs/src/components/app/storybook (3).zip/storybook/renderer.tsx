"use client";

import { AnimatePresence, motion } from "motion/react";
import { cn } from "@/lib/utils";
import { useStoryBook } from "@/components/app/storybook/utils/use-story-book";
import { StoryBookCode } from "@/components/app/storybook/components/code";
import { StoryBookControls } from "@/components/app/storybook/components/controls";
import { StoryBookHeader } from "@/components/app/storybook/components/header";
import { StoryBookPreview } from "@/components/app/storybook/components/preview";
import type { StoryBookConfig } from "@/components/app/storybook/types";

type StoryBookRendererProps<TArgs extends object> = {
  story: StoryBookConfig<TArgs>;
};

export function StoryBookRenderer<TArgs extends object>({
  story,
}: StoryBookRendererProps<TArgs>) {
  const { args, code, controls, showCode, setShowCode, updateArg } =
    useStoryBook(story);

  const preview = story.render ? (
    story.render(args)
  ) : story.component ? (
    <story.component {...args} />
  ) : null;

  return (
    <div className="flex w-full flex-col overflow-hidden divide-y">
      <StoryBookHeader
        code={code}
        setShowCode={setShowCode}
        showCode={showCode}
      />

      <AnimatePresence initial={false}>
        {showCode && (
          <motion.div
            initial={{
              height: 0,
              opacity: 0,
            }}
            animate={{
              height: "auto",
              opacity: 1,
            }}
            exit={{
              height: 0,
              opacity: 0,
            }}
            transition={{
              duration: 0.25,
              ease: "easeInOut",
            }}
            className="overflow-hidden border-b"
          >
            <div className="min-h-0">
              <StoryBookCode code={code} />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <StoryBookControls
        controls={controls}
        args={args}
        layout={story.layout}
        onChange={updateArg}
      />

      <StoryBookPreview>{preview}</StoryBookPreview>
    </div>
  );
}
