import type { ComponentType, ReactElement, ReactNode } from "react";

export type StoryBookSelectOption = {
  value: string | number;
  label: string;
};

type StoryBookTextControl = {
  type: "text";
  label?: string;
  placeholder?: string;
};

type StoryBookTextareaControl = {
  type: "textarea";
  label?: string;
  placeholder?: string;
};

type StoryBookBooleanControl = {
  type: "boolean";
  label?: string;
};

type StoryBookNumberControl = {
  type: "number";
  label?: string;
  placeholder?: string;
  min?: number;
  max?: number;
};

type StoryBookSelectControl = {
  type: "select";
  label?: string;
  options: readonly StoryBookSelectOption[];
};

type StoryBookToggleGroupControl = {
  type: "toggle-group";
  label?: string;
  options: readonly StoryBookSelectOption[];
};

export type StoryBookControl =
  | StoryBookTextControl
  | StoryBookTextareaControl
  | StoryBookBooleanControl
  | StoryBookNumberControl
  | StoryBookSelectControl
  | StoryBookToggleGroupControl;

export type StoryBookFieldStyle = {
  colSpan?: number;
  className?: string;
};

export type StoryBookField<T> = {
  defaultValue: T;
  showDefault?: boolean;
  control?: StoryBookControl;
  style?: StoryBookFieldStyle;
};

export type StoryBookArgs<TArgs extends object> = {
  [K in keyof TArgs]: StoryBookField<TArgs[K]>;
};

export type StoryBookLayout = {
  control?: {
    columns?: number;
    className?: string;
  };
};

export type StoryBookCode = {
  imports?: string[];
  element: ReactElement;
};

export type StoryBookConfig<TArgs extends object> = {
  title: string;
  component?: ComponentType<TArgs>;
  layout?: StoryBookLayout;
  args: StoryBookArgs<TArgs>;
  render?: (args: TArgs) => ReactNode;
  code?: (args: TArgs) => StoryBookCode;
};
