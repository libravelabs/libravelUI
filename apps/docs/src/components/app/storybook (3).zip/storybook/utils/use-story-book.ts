import { useCallback, useEffect, useMemo, useState } from "react";
import { formatCode } from "@/components/app/storybook/format-code";
import { stringifyStoryBookCode } from "@/components/app/storybook/serialize";
import type { StoryBookConfig } from "@/components/app/storybook/types";
import { getDefaultArgs, typedEntries } from "./utils";

export function useStoryBook<TArgs extends object>(
  story: StoryBookConfig<TArgs>,
) {
  const [showCode, setShowCode] = useState(false);

  const defaultArgs = useMemo(() => getDefaultArgs(story.args), [story.args]);

  const controls = useMemo(
    () => typedEntries(story.args).filter(([, field]) => field.control),
    [story.args],
  );

  const [args, setArgs] = useState<TArgs>(defaultArgs);
  const [code, setCode] = useState<string | null>(null);

  useEffect(() => {
    setArgs(defaultArgs);
  }, [defaultArgs]);

  const updateArg = useCallback(
    <K extends keyof TArgs>(key: K, value: TArgs[K]) => {
      setArgs((current) => ({
        ...current,
        [key]: value,
      }));
    },
    [],
  );

  const rawCode = story.code
    ? stringifyStoryBookCode({
        title: story.title,
        defaults: defaultArgs,
        ...story.code(args),
      })
    : null;

  useEffect(() => {
    if (!rawCode) {
      setCode(null);
      return;
    }

    let cancelled = false;

    formatCode(rawCode).then((formatted) => {
      if (!cancelled) {
        setCode(formatted.trim());
      }
    });

    return () => {
      cancelled = true;
    };
  }, [rawCode]);

  return {
    args,
    code,
    controls,
    showCode,
    setShowCode,
    updateArg,
  };
}
