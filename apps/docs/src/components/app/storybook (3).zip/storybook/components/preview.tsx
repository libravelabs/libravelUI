import type { ReactNode } from "react";

type StoryBookPreviewProps = {
  children: ReactNode;
};

export function StoryBookPreview({ children }: StoryBookPreviewProps) {
  return (
    <div className="relative flex min-h-60 items-center justify-center px-6 py-10 sm:px-10">
      <div className="relative flex w-full items-center justify-center">
        {children}
      </div>
    </div>
  );
}
