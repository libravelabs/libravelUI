import { CodeBlock } from "@/components/docs/code-block";

type StoryBookCodeProps = {
  code: string | null;
};

export function StoryBookCode({ code }: StoryBookCodeProps) {
  if (!code) {
    return null;
  }

  return (
    <div className="flex min-h-full flex-col overflow-hidden">
      <CodeBlock
        lang="tsx"
        code={code}
        className="h-full w-full max-w-none rounded-none border-none"
      />
    </div>
  );
}
