import { cn } from "@/lib/utils";
import { StoryBookControlField } from "@/components/app/storybook/components/control-field";
import type {
  StoryBookArgs,
  StoryBookLayout,
} from "@/components/app/storybook/types";
import { getControlColumnClass, getControlSpanClass } from "../utils/utils";

type StoryBookControlsProps<TArgs extends object> = {
  controls: readonly [keyof TArgs, StoryBookArgs<TArgs>[keyof TArgs]][];
  args: TArgs;
  layout?: StoryBookLayout;
  onChange<K extends keyof TArgs>(key: K, value: TArgs[K]): void;
};

export function StoryBookControls<TArgs extends object>({
  controls,
  args,
  layout,
  onChange,
}: StoryBookControlsProps<TArgs>) {
  if (controls.length === 0) {
    return null;
  }

  return (
    <div
      className={cn(
        "grid grid-cols-1 items-center p-4 gap-5 sm:p-5",
        getControlColumnClass(layout?.control?.columns),
        layout?.control?.className,
      )}
    >
      {controls.map(([name, field]) => (
        <div
          key={String(name)}
          className={cn(
            "col-span-1",
            getControlSpanClass(field.style?.colSpan),
            field.style?.className,
          )}
        >
          <StoryBookControlField
            name={String(name)}
            control={field.control!}
            value={args[name]}
            onChange={(value) => onChange(name, value as TArgs[typeof name])}
          />
        </div>
      ))}
    </div>
  );
}
